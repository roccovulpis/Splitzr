import React from 'react'

export default function Waves() {
  return (
    <div id="bg">
        <div className="wave"></div>
        <div className="wave"></div>
        <div className="wave"></div>
    </div>
  )
}
