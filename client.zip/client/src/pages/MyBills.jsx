import React from 'react'

export default function MyBills() {
  return (
    <div>
      <h1>My Bills</h1>
    </div>
  )
}
